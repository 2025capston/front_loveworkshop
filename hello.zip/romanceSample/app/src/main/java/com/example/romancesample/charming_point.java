package com.example.romancesample;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.app.AlertDialog;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.InputStream;
import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class charming_point extends AppCompatActivity {

    private static final int GET_GALLERY_IMAGE = 200;

    Button gallerybtn;
    ImageView imageView;
    Uri galleryUri;
    ImageView next5;

    Uri frontUri;
    Uri leftUri;
    Uri rightUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_charming_point);

        gallerybtn = findViewById(R.id.button12);
        imageView = findViewById(R.id.imageView3);
        next5= findViewById(R.id.next5);

        next5.setOnClickListener(v -> {
            Intent intent = new Intent(charming_point.this, choose_clone.class);
            startActivity(intent);
        }
        );}
}
