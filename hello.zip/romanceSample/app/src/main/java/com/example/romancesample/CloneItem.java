package com.example.romancesample;

public class CloneItem {
    int imageResId;
    String name;
    String contents;

    public CloneItem(int imageResId, String name, String contents) {
        this.imageResId = imageResId;
        this.name = name;
        this.contents = contents;
    }
}
