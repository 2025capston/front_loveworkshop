package com.example.romancesample;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;

import java.util.ArrayList;

public class choose_place_m extends AppCompatActivity {

    TextView place1, place2, place3;
    LinearLayout linearLayout2;

    String selectedPlace = "";
    String selectedDateTime = "";

    TextView prevSelectedPlace = null;
    TextView prevSelectedDateTime = null;

    Button sendMatchButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_choose_place_m);

        place1 = findViewById(R.id.place1);
        place2 = findViewById(R.id.place2);
        place3 = findViewById(R.id.place3);
        linearLayout2 = findViewById(R.id.linearLayout2);
        sendMatchButton = findViewById(R.id.send_match);

        Intent intent = getIntent();
        ArrayList<String> dateTimeList = intent.getStringArrayListExtra("datetime_list");

        place1.setText(intent.getStringExtra("place1"));
        place2.setText(intent.getStringExtra("place2"));
        place3.setText(intent.getStringExtra("place3"));

        // 날짜/시간 목록 보여주기
        for (String dateTime : dateTimeList) {
            TextView tv = new TextView(this);
            tv.setText(dateTime);
            tv.setTextSize(18);
            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            tv.setBackgroundResource(R.drawable.calender_src);
            tv.setTypeface(ResourcesCompat.getFont(this, R.font.scd5));
            tv.setPadding(8, 8, 8, 8);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    (int) (getResources().getDisplayMetrics().density * 350),
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.topMargin = (int) (getResources().getDisplayMetrics().density * 10);
            tv.setLayoutParams(params);

            tv.setOnClickListener(v -> {
                if (prevSelectedDateTime != null) {
                    prevSelectedDateTime.setTextColor(Color.BLACK);
                }

                selectedDateTime = dateTime;
                tv.setTextColor(ContextCompat.getColor(this, R.color.button_selected_color));
                prevSelectedDateTime = tv;
            });

            linearLayout2.addView(tv);
        }

        // 장소 클릭 리스너 공통 처리
        View.OnClickListener placeClickListener = v -> {
            TextView clicked = (TextView) v;

            if (prevSelectedPlace != null) {
                prevSelectedPlace.setTextColor(Color.BLACK);
            }

            selectedPlace = clicked.getText().toString();
            clicked.setTextColor(ContextCompat.getColor(this, R.color.button_selected_color));
            prevSelectedPlace = clicked;
        };

        place1.setOnClickListener(placeClickListener);
        place2.setOnClickListener(placeClickListener);
        place3.setOnClickListener(placeClickListener);

        // send_match 버튼 클릭 시 이동
        sendMatchButton.setOnClickListener(v -> {
            if (!selectedPlace.isEmpty() && !selectedDateTime.isEmpty()) {
                Intent nextIntent = new Intent(choose_place_m.this, wait_day3.class);
                nextIntent.putExtra("selected_place", selectedPlace);
                nextIntent.putExtra("selected_datetime", selectedDateTime);
                startActivity(nextIntent);
                finish();
            } else {
                Toast.makeText(this, "장소와 날짜/시간을 선택해 주세요!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
