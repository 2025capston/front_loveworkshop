package com.example.romancesample;

public class SelectData {
    public static int km = 0; // 거리
    public static int ageMin = -5; // 연하
    public static int ageMax = 5;  // 연상
}
