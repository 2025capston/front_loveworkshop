package com.example.romancesample;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class choose_clone extends AppCompatActivity {

    private ImageView imageOfYourLuv;
    private ActivityResultLauncher<String> getImageLauncher;

    // [추가] 선택한 이미지의 URI 저장 변수
    private Uri selectedImageUri = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_choose_clone);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView textView = findViewById(R.id.textView);
        SeekBar seekBar = findViewById(R.id.seekBar);
        imageOfYourLuv = findViewById(R.id.imageofyourLuv);
        Button inputClonePic = findViewById(R.id.input_clonepic);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int value = progress + 5;
                textView.setText("현재 값: " + value);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // [수정] 이미지 선택 런처 정의
        getImageLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        selectedImageUri = uri; // [추가] URI 저장
                        imageOfYourLuv.setImageURI(uri);
                    }
                });

        inputClonePic.setOnClickListener(v -> {
            getImageLauncher.launch("image/*");
        });

        // [수정] 이미지 URI를 Intent로 넘김
        ImageView gotomatch = findViewById(R.id.gotomatch);
        gotomatch.setOnClickListener(v -> {
            Intent intent = new Intent(choose_clone.this, show_clones.class);
            if (selectedImageUri != null) {
                intent.putExtra("image_uri", selectedImageUri.toString()); // [추가] URI 전달
            }
            startActivity(intent);
        });

        Button womanButton = findViewById(R.id.woman);
        Button manButton = findViewById(R.id.man);
        Button bothButton = findViewById(R.id.both);

        int selectedColor = getResources().getColor(R.color.button_selected_color);

        womanButton.setOnClickListener(v -> womanButton.setBackgroundTintList(ColorStateList.valueOf(selectedColor)));
        manButton.setOnClickListener(v -> manButton.setBackgroundTintList(ColorStateList.valueOf(selectedColor)));
        bothButton.setOnClickListener(v -> bothButton.setBackgroundTintList(ColorStateList.valueOf(selectedColor)));
    }
}
