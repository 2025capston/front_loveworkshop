package com.example.romancesample.model;

public class LoginResponse {
    private String token;

    public String getToken() {
        return token;
    }
}